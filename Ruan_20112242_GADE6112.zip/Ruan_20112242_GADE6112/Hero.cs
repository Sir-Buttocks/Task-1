﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruan_20112242_GADE6112
{
    class Hero : Character
    {
        public Hero(int y, int x, int Hp) : base(y, x) ///Q2.6-Firts dot 
        {
            this.Damage = 2;
        }
        
    }
}
