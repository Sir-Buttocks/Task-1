﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruan_20112242_GADE6112
{
    abstract class Tile //Create an abstract base class called Tile
    {

        protected string X;
        protected string Y;

        public enum TileType { Hero, Enemy, Gold, Weapon };  //is used to assign constant names to a group of numeric integer values

        public Tile(int y, int x)
        {
        }

        public int y { get => y; set => y = value; }

        public int x { get => x; set => x = value; }

    }

    
}
