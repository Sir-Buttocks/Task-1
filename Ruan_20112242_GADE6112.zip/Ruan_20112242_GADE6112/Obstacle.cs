﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruan_20112242_GADE6112
{
    class Class1
    {
        public class Obstacle : Tile //Obstacle is the subclass
        {


            public Obstacle(int y, int x) : base(y, x) ///Q2.1-calling a constructor 
            {

            }
        


        }
    }
}
