﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruan_20112242_GADE6112
{
    abstract class Enemy : Character
    {
        //Q2.4 First dot
        Random r = new Random();

        static int Randomnumber(Random r)
        {
            return r.Next();
        }
        //Q2.4 Seconde dot
        public Enemy(int y, int x, int Damage, int MaxHP) : base(y, x)
        {

        }
        //Q2.4-Third dot
        protected Enemy(int y, int x)
        {
            this.y = y;
            this.x = x;
        }

      
    }

}
