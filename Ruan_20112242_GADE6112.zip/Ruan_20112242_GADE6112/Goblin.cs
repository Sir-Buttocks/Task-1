﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruan_20112242_GADE6112
{
    class Goblin : Enemy //Q2.5
    {
        //Q2.5-First dot
        public Goblin(string symbol, int y, int x) : base(y, x, 1, 10) //2.5-Goblin Hp and Damage
        {

        }
    }
}
