﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruan_20112242_GADE6112
{
    public class  Character : Tile //Q2.2-class called Character that inherits from Tile  /////////////dit clash met Tile//////////////
    {
        protected int HP;
        protected int MaxHp;
        protected int Damage;


        string[] chvision = new string[4] {"north", "south", "east", "west" };

        public enum Movement { NoMovement, Up, Down, Left, Right }; // A public enum for Movement which contains definitions

        public int Hp { get => Hp; set => Hp = value; }
        public int MaxHP { get => MaxHP; set => MaxHP = value; }
        public int damage { get => damage; set => damage = value; }

       /////////Q2.3

        public Character( int y,int x) : base(y, x)//Q2.3 Firts dot 
        {
        }

        public Character(int y, int x, int hp) : this(y, x)
        {
        }

        public virtual void attack(Character target)
        {
            HP -= Damage;
        }
        public bool IsDead()
        {
            if (Hp <= 0)
            {
                return true;
            }
            else
                return false;
        }
        public int DistanceTo()///
        {

        }
        public virtual bool CheckRange()////
        {

        }
        public void Move(Movement move)
        {
            switch (move)
            {
                case Movement.NoMovement:
                    y = y + 0;
                    x = x + 0;
                    break;
                case Movement.Up:
                    y = y + 1;
                    break;
                case Movement.Down:
                    y = y + 1;
                    break;
                case Movement.Right:
                    x = x + 1;
                    break;
                case Movement.Left:
                    x = x + 1;
                    break;
            }
        }
    }
}
