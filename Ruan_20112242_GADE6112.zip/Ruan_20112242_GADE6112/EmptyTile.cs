﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruan_20112242_GADE6112
{
    class Class2
    {
        public class EmptyTile : Tile //EmptyTile is the subclass-merely exists to denote an empty tile.
        {
            public string Tile(int x, int y)
            {

            }
        }
    }
}
